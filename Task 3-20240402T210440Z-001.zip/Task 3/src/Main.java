public class Main {
    public static void main(String[] args) {
        Thread[] threads = new Thread[3];

        // Create a common lock object for synchronization
        Object lock = new Object();

        // Launch three tasks concurrently
        for (int i = 0; i < 3; i++) {
            threads[i] = new Thread(new LongRunningTask(i + 1, lock));
            threads[i].start();
        }

        // Wait for all threads to complete
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("All tasks completed");
    }
}