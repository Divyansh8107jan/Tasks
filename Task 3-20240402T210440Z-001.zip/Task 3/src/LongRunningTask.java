class LongRunningTask implements Runnable {
    private int taskId;
    private Object lock;

    public LongRunningTask(int id, Object lock) {
        this.taskId = id;
        this.lock = lock;
    }

    @Override
    public void run() {
        System.out.println("Task " + taskId + " started");
        try {
            // Emulate delay with Thread.sleep for 5 seconds
            synchronized (lock) {
                Thread.sleep(5000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Task " + taskId + " completed");
    }
}