import java.util.ArrayList;
import java.util.List;

public class CombinationSum {

    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50, 60, 70, 80, 90};
        int target = 100;

        List<List<Integer>> result = findCombinations(array, target);

        for (List<Integer> combination : result) {
            System.out.print("{");
            for (int i = 0; i < combination.size(); i++) {
                System.out.print(combination.get(i));
                if (i < combination.size() - 1) {
                    System.out.print(",");
                }
            }
            System.out.println("}");
        }
    }

    public static List<List<Integer>> findCombinations(int[] array, int target) {
        List<List<Integer>> result = new ArrayList<>();
        findCombinationsHelper(array, target, 0, new ArrayList<>(), result);
        return result;
    }

    private static void findCombinationsHelper(int[] array, int target, int index, List<Integer> current, List<List<Integer>> result) {
        if (target == 0) {
            result.add(new ArrayList<>(current));
            return;
        }

        for (int i = index; i < array.length; i++) {
            if (target - array[i] >= 0) {
                current.add(array[i]);
                findCombinationsHelper(array, target - array[i], i + 1, current, result);
                current.remove(current.size() - 1);
            }
        }
    }
}
