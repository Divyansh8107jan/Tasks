package com.shoppingmall.shoppingmall.service;


import com.shoppingmall.shoppingmall.entity.Price;
import com.shoppingmall.shoppingmall.repository.PriceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class DealService {

    @Autowired
    private PriceRepository priceRepository;

    public String findBestDeal(Long productId) {

        List<Price> prices = priceRepository.findByProductId(productId);

        if (prices.isEmpty()) {
            return "No prices found for the product.";
        }


        Optional<Price> bestPriceOptional = prices.stream()
                .min(Comparator.comparing(Price::getPrice));

        if (bestPriceOptional.isPresent()) {

            Price bestPrice = bestPriceOptional.get();
            return "Best deal for " + bestPrice.getProduct().getName() +
                    " is available at " + bestPrice.getShop().getName() +
                    " for Rupees" + bestPrice.getPrice();
        } else {
            return "Failed to determine the best deal.";
        }
    }
}
