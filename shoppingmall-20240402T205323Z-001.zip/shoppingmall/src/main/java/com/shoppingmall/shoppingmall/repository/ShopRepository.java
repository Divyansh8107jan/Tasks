package com.shoppingmall.shoppingmall.repository;

import com.shoppingmall.shoppingmall.entity.Shop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopRepository extends JpaRepository<Shop , Long> {
}
